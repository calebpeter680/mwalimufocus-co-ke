$(document).ready(function() {
    $('#subscribeButton').on('click', function() {
        const email = $('#newsletterEmail').val().trim();

        if (email) {
            subscribeToNewsletter(email);
        } else {
            displaySubscriptionMessage({ 'error': 'Please provide a valid email address.' });
        }
    });
});

function subscribeToNewsletter(email) {
    const formData = {
        'email': email
    };

    $.ajax({
        type: 'POST',
        url: '/accounts/api/create-subscriber/',
        data: JSON.stringify(formData),
        contentType: 'application/json',
        success: function(response) {
            displaySubscriptionMessage(response);
        },
        error: function(xhr, status, error) {
            console.error('Error subscribing to newsletter:', error);
            displaySubscriptionMessage({ 'error': 'Failed to subscribe. Please try again later.' });
        }
    });
}

function displaySubscriptionMessage(response) {
    const messageContainer = $('#subscriptionMessageContainer');
    messageContainer.empty();

    if (response.message) {
        messageContainer.addClass('text-success').text(response.message);
    } else if (response.error) {
        messageContainer.addClass('text-danger').text(response.error);
    }
}
